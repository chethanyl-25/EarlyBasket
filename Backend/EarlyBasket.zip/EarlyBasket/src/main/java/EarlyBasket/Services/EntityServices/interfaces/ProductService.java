package EarlyBasket.Services.EntityServices.interfaces;

import EarlyBasket.entities.Product;

public interface ProductService {
    public Product save(Product product);
}
